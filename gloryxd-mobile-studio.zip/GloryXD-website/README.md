# GloryXD — Studio website

Website giới thiệu GloryXD — mobile game studio — gồm một trang tiếng Anh dành cho người chơi và đối tác/publisher. Giao diện sáng với màu kem, tím và pastel; ba màn hình điện thoại cùng các demo Puzzle, Match-3 và Tile Match. Có cửa sổ chi tiết concept, menu điện thoại và liên hệ qua **gloryxdinc@gmail.com**.

## Xem trên máy

Mở `index.html` trực tiếp trong trình duyệt, hoặc chạy từ thư mục này:

```sh
python3 -m http.server 4173 --bind 127.0.0.1
```

Sau đó truy cập <http://127.0.0.1:4173>. Không cần cài thư viện hay chạy bước build.

## Đưa lên GitHub Pages

1. Tạo repository GitHub và đưa toàn bộ nội dung thư mục này vào nhánh `main`. Giữ file `index.html` ở thư mục gốc và giữ file `.nojekyll`.
2. Mở **Settings → Pages** của repository.
3. Trong **Build and deployment → Source**, chọn **Deploy from a branch**.
4. Chọn nhánh **main**, thư mục **/(root)**, rồi **Save**.
5. Đợi GitHub hoàn tất xuất bản. Đường dẫn sẽ xuất hiện trong mục Pages.

Các đường dẫn tài nguyên dùng dạng tương đối nên hoạt động với cả `username.github.io` và `username.github.io/repository/`.

Hướng dẫn chính thức: <https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site>.

## Thay nội dung và hình ảnh

| File | Nội dung |
| --- | --- |
| `index.html` | Logo tạm, nội dung trang, tên và mô tả ngắn của các game, thông tin SEO |
| `styles.css` | Màu sắc, kiểu chữ, bố cục máy tính/điện thoại |
| `site.config.js` | Email và nội dung cửa sổ chi tiết từng concept |
| `app.js` | Menu, cửa sổ chi tiết, điều hướng, năm bản quyền |
| `assets/images/match3-demo.webp` | Demo Match-3 — Sweet Match |
| `assets/images/tiles-demo.webp` | Demo Tile Match — Tile Picnic |
| `assets/images/puzzle-demo.webp` | Demo Block Puzzle — Pocket Blocks |
| `assets/favicon.svg` | Biểu tượng tab trình duyệt tạm |

Để thay logo, thay SVG và chữ trong liên kết `.brand` của `index.html`, cập nhật `.footer-brand` và `assets/favicon.svg` nếu cần.

Để thay game, sửa cả thẻ game trong `index.html` và đối tượng tương ứng trong `site.config.js`. Giữ khóa `data-project` của thẻ khớp với khóa trong cấu hình. Khi đưa game thật vào trang, thay nhãn **Demo concept**, nội dung chú thích và đường dẫn theo thông tin chính thức của game.

Email đã được điền trong HTML để vẫn hoạt động khi tắt JavaScript. Khi đổi email, cập nhật trong `site.config.js` và các liên kết `mailto:` của `index.html`.

## Tài nguyên

- Ba hình demo mobile game được tạo bằng công cụ ImageGen tích hợp. Đây là ảnh minh họa, không phải game đã phát hành hay demo có thể chơi. Bộ prompt hiện tại được lưu tại `docs/mobile-demo-prompts.md`. Các ảnh và prompt trong bản thiết kế trước được giữ lại để tham khảo và không được trang sử dụng.
- Logo chữ và biểu tượng bốn ô màu là thiết kế tạm bằng SVG/CSS.
- Font DM Sans được lưu trong `assets/fonts`, kèm giấy phép SIL Open Font License. Font Barlow Condensed từ bản trước cũng được giữ lại nhưng không được giao diện hiện tại sử dụng. Trang không cần tải font hoặc script từ bên thứ ba.
- Trang không dùng biểu mẫu gửi dữ liệu, dịch vụ theo dõi, tài khoản hay máy chủ xử lý. Nút liên hệ mở ứng dụng email của khách truy cập.
